from django.contrib import admin
from .models import AboutPageBody


admin.site.register(AboutPageBody)
